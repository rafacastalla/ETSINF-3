﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GestDepLib.Persistence;
using GestDepLib.Entities;
using System.Linq;

namespace GestDep.UnitTest
{
    [TestClass]
    public class EntityFrameworkDalTest
    {
        private IDAL dal;

        [TestInitialize]
        public void Initialize()
        {
            dal = new EntityFrameworkDAL(new GestDepDbContext());
            DataSamples.CreateSampleDB(dal);
        }

        //[Ignore]
        [TestMethod]
        public void TestEntityFrameworkDAL()
        {
            // Test Pool and lanes
            Assert.AreEqual(1, dal.GetAll<Pool>().Count());
            Pool pool = dal.GetAll<Pool>().First();
            Assert.AreEqual(pool.ZipCode, 46122);
            Assert.AreEqual(pool.OpeningHour.TimeOfDay, createTime(8, 0, 0).TimeOfDay);
            Assert.AreEqual(pool.Lanes.Count, 6);
            Lane l1 = pool.FindLaneByNumer(1);
            Lane l2 = pool.FindLaneByNumer(2);
            Lane l3 = pool.FindLaneByNumer(3);
            Lane l6 = pool.FindLaneByNumer(6);
            Assert.AreEqual(1, l1.Courses.Count);
            Assert.AreEqual(1, l2.Courses.Count);
            Assert.AreEqual(1, l3.Courses.Count);
            Assert.AreEqual(0, l6.Courses.Count);

            // Test Courses
            Assert.AreEqual(2, dal.GetAll<Course>().Count());
            Course c1 = l1.Courses.First();
            Course c2 = l2.Courses.First();
            Course c3 = l3.Courses.First();
            Assert.AreEqual(c1, c2);
            Assert.AreNotEqual(c1, c3);
            Assert.AreEqual(c1.StartDate, new DateTime(2017, 11, 6));
            Assert.AreEqual(c3.StartDate, new DateTime(2017, 11, 7));
            Assert.AreEqual(c1.StartDate, new DateTime(2017, 11, 6));
            Assert.AreEqual(c3.StartDate, new DateTime(2017, 11, 7));
            Assert.IsFalse(c1.Cancelled);
            Assert.IsTrue(c3.Cancelled);
            Assert.AreEqual(c1.CourseDays, Days.Monday | Days.Wednesday | Days.Friday);
            Assert.AreEqual(c3.CourseDays, Days.Tuesday | Days.Thursday);

            // Test people
            Assert.AreEqual(1, dal.GetAll<Monitor>().Count());
            Assert.AreEqual(5, dal.GetAll<User>().Count());

            User Ona = dal.GetById<User>("1234567890");
            Assert.AreEqual(Ona.Name, "Ona Carbonell");
            foreach (Enrollment en in Ona.Enrollments)
                Assert.AreEqual(en.User, Ona);

            Monitor Phelps = dal.GetById<Monitor>("X-00000001");
            Assert.AreEqual(c1.Monitor, Phelps);
            Assert.IsNull(c3.Monitor);
            Assert.AreEqual(1, Phelps.Courses.Count);
            Assert.AreEqual(c1, Phelps.Courses.First());

            // Enrollments
            Assert.AreEqual(3, c1.Enrollments.Count);
            Assert.AreEqual(2, c3.Enrollments.Count);

            // Payments
            Assert.AreEqual(8, dal.GetAll<Payment>().Count());
            Assert.AreEqual(3, dal.GetWhere<Payment>(p => p.Description == "Free Swim").Count());
            //foreach (Payment pay in dal.GetAll<Payment>())
            //{
            //    if (pay.Description == "Free Swim") Assert.AreEqual(pay.Quantity, pool.FreeSwimPrice);
            //}
        }

        public static DateTime createTime(int hours, int minutes, int seconds)
        {
            DateTime now = DateTime.Now;
            return new DateTime(now.Year, now.Month, now.Day, hours, minutes, seconds);
        }
    }
}
