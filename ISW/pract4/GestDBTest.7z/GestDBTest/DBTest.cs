﻿using GestDepLib.Persistence;
using GestDepLib.Entities;
using System.Linq;
using GestDepLib;
using System;
using System.Data.Entity;
using System.Text;

namespace GestDep.Testing
{
    class DBTest
    {
        static void Main(string[] args)
        {
           IDAL dal = new EntityFrameworkDAL(new GestDepDbContext());
           populateDB(dal);
           displayData(dal);
        }

        private static void populateDB(IDAL dal)
        {
            // Remove all data from DB
            

            // Populate the database with the data described in lab 4 bulletin (see Apendix)


        }

        private static void displayData(IDAL dal)
        {
            Pool pool = dal.GetAll<Pool>().First();
            foreach (Course course in dal.GetAll<Course>())
            {
                Console.WriteLine("===================================");
                Console.WriteLine("         Course details         ");
                Console.WriteLine("===================================");
                Console.WriteLine(CourseToString(course));
                //foreach (Days day in Enum.GetValues(typeof(Days)))
                //{
                //    if ((course.CourseDays & day) == day)
                //        Console.WriteLine("Course on " + day.ToString());
                //}
            }
            Console.WriteLine("Payments:");
            foreach (Payment pay in dal.GetAll<Payment>())
                Console.Write(PaymentToString(pay));
            Console.WriteLine("Pres Key to exit...");
            Console.ReadKey();
        }

        public static String PersonToString(Person person)
        {
            return person.Name + " (" + person.Id + ")";
        }

        public static String CourseToString(Course course)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("StartDate: " + course.StartDate);
            sb.AppendLine("FinishDate: " + course.FinishDate);
            sb.AppendLine("Days : " + course.CourseDays);
            sb.AppendLine("Price: " + course.Price);
            sb.AppendLine("Lanes assigned: ");
            foreach (Lane lane in course.Lanes)
                sb.AppendLine(" Lane " + lane.Number);
            if (course.Monitor != null)
                sb.AppendLine("\nUsers enrolled in course " + course.Description + ", with monitor " + PersonToString(course.Monitor));
            else sb.AppendLine("\nUsers enrolled in course " + course.Description + ", with no monitor yet");
            foreach (Enrollment en in course.Enrollments)
            {
                sb.Append(" " + EnrollmentToString(en));
            }
            //sb.AppendLine("");
            return sb.ToString();
        }

        public static String EnrollmentToString(Enrollment en)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(PersonToString(en.User) + " enrolled on " + en.EnrollmentDate);
            return sb.ToString();
        }

        public static String PaymentToString(Payment pay)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(" " + pay.Date + " -> " + pay.Description + ": " + pay.Quantity);
            return sb.ToString();
        }


        private static DateTime createTime(int hours, int minutes, int seconds)
        {
            DateTime now = DateTime.Now;
            return new DateTime(now.Year, now.Month, now.Day, hours, minutes, seconds);
        }

    }
}
