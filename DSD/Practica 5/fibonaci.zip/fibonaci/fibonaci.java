
/**
 * Write a description of class fibonaci here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class fibonaci
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class fibonaci
     */
    public static void main(String args[])
    {
        System.out.print("Valor de fibonacci final: "+fib()+"\n");
    }

    public static int fib(){
        int n = 8; /* calcula el n-ésimo número de Fibonacci */
        int f1 = 1, f2 = -1; /* últimos dos números de Fibonacci */
            while (n != 0) { /* cuenta hasta n = 0 */
                f1 = f1 + f2;
                f2 = f1 - f2;
                System.out.print("Valor de f1 en la iteración "+ n +" : " + f1+"\n");
                n = n - 1;
            }
        return f1;
    }
}
